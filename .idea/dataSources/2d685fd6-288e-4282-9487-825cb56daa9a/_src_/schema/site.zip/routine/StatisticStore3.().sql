CREATE PROCEDURE StatisticStore3()
  BEGIN
    declare _n varchar(20);
    declare done int default false;
    declare cur cursor for select name from store group by name;
    declare continue HANDLER for not found set done = true;
    open cur;
    read_loop:loop
      fetch cur into _n;
      if done then
        leave read_loop;
      end if;
      begin
        declare c int;
        declare n varchar(20);
        declare total int default 0;
        declare done int default false;
        declare cur cursor for select name,count from store where name = 'iphone';
        declare continue HANDLER for not found set done = true;
        set total = 0;
        open cur;
        iphone_loop:loop
          fetch cur into n,c;
          if done then
            leave iphone_loop;
          end if;
          set total = total + c;
        end loop;
        close cur;
        select _n,n,total;
      end;
      begin
        declare c int;
        declare n varchar(20);
        declare total int default 0;
        declare done int default false;
        declare cur cursor for select name,count from store where name = 'android';
        declare continue HANDLER for not found set done = true;
        set total = 0;
        open cur;
        android_loop:loop
          fetch cur into n,c;
          if done then
            leave android_loop;
          end if;
          set total = total + c;
        end loop;
        close cur;
        select _n,n,total;
      end;
      begin

      end;
    end loop;
    close cur;
  END;
